gdjs._22330_26223_95G1_9503Code = {};
gdjs._22330_26223_95G1_9503Code.forEachIndex2 = 0;

gdjs._22330_26223_95G1_9503Code.forEachIndex3 = 0;

gdjs._22330_26223_95G1_9503Code.forEachObjects2 = [];

gdjs._22330_26223_95G1_9503Code.forEachObjects3 = [];

gdjs._22330_26223_95G1_9503Code.forEachTemporary2 = null;

gdjs._22330_26223_95G1_9503Code.forEachTemporary3 = null;

gdjs._22330_26223_95G1_9503Code.forEachTotalCount2 = 0;

gdjs._22330_26223_95G1_9503Code.forEachTotalCount3 = 0;

gdjs._22330_26223_95G1_9503Code.repeatCount5 = 0;

gdjs._22330_26223_95G1_9503Code.repeatIndex5 = 0;

gdjs._22330_26223_95G1_9503Code.GDplayerObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayerObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayerObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayerObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayerObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects1= [];
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects2= [];
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects3= [];
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects4= [];
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects5= [];
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects6= [];
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects7= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects7= [];
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects1= [];
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2= [];
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3= [];
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects4= [];
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects5= [];
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects6= [];
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects7= [];

gdjs._22330_26223_95G1_9503Code.conditionTrue_0 = {val:false};
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0 = {val:false};
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0 = {val:false};
gdjs._22330_26223_95G1_9503Code.condition2IsTrue_0 = {val:false};
gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = {val:false};
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_1 = {val:false};
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_1 = {val:false};
gdjs._22330_26223_95G1_9503Code.condition2IsTrue_1 = {val:false};


gdjs._22330_26223_95G1_9503Code.eventsList0xbdbd34 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.createFrom(runtimeScene.getObjects("player_starlight_Red"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.createFrom(runtimeScene.getObjects("player_starlight_blue"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.createFrom(runtimeScene.getObjects("player_starlight_yellow"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[i].setPosition((( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[0].getPointX("")),(( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[i].setPosition((( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[0].getPointX("")),(( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[0].getPointY("")));
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[i].setPosition((( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[0].getPointX("")),(( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[0].getPointY("")));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xbdbd34
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595starlight_9595yellowObjects3Objects = Hashtable.newFrom({"player_starlight_yellow": gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects3});gdjs._22330_26223_95G1_9503Code.eventsList0xcde83c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20322292);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595starlight_9595yellowObjects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), "player");
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xcde83c
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595starlight_9595blueObjects4Objects = Hashtable.newFrom({"player_starlight_blue": gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595yuanObjects3Objects = Hashtable.newFrom({"player_yuan": gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3});gdjs._22330_26223_95G1_9503Code.eventsList0xa4dbec = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(8945028);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595starlight_9595blueObjects4Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointX("")), "player");
}}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.001, "蓝色圆圈");
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects3 */
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595yuanObjects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3[i].setZOrder((( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3[i].setColor("48;169;253");
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3[i].setBlendMode(1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "蓝色圆圈");
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xa4dbec
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595starlight_9595RedObjects4Objects = Hashtable.newFrom({"player_starlight_Red": gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595yuanObjects3Objects = Hashtable.newFrom({"player_yuan": gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3});gdjs._22330_26223_95G1_9503Code.eventsList0x89533c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15594580);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595starlight_9595RedObjects4Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointX("")), "player");
}}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.001, "红色圆圈");
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects3 */
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595yuanObjects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3[i].setZOrder((( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[0].getZOrder()) - 1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3[i].setColor("243;26;29");
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3[i].setBlendMode(1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "红色圆圈");
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x89533c
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects3Objects = Hashtable.newFrom({"Border_collision": gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects4Objects = Hashtable.newFrom({"player_effects_circular_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4});gdjs._22330_26223_95G1_9503Code.eventsList0x13027a4 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13421028);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects4Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setColor("255;255;255");
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x13027a4
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects4Objects = Hashtable.newFrom({"player_effects_circular_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4});gdjs._22330_26223_95G1_9503Code.eventsList0xe83554 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10823444);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects4Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setColor("0;123;255");
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xe83554
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects4Objects = Hashtable.newFrom({"player_effects_circular_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4});gdjs._22330_26223_95G1_9503Code.eventsList0x114d604 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(18881492);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects4Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4[i].setColor("197;0;56");
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x114d604
gdjs._22330_26223_95G1_9503Code.eventsList0xb68bac = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x13027a4(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xe83554(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i].getVariables().getFromIndex(0)) == 2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x114d604(runtimeScene);} //End of subevents
}

}


{


{
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb68bac
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects3Objects = Hashtable.newFrom({"player_effects_circular_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3});gdjs._22330_26223_95G1_9503Code.eventsList0xc6131c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15276476);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setColor("255;255;255");
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xc6131c
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects3Objects = Hashtable.newFrom({"player_effects_circular_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3});gdjs._22330_26223_95G1_9503Code.eventsList0x11815dc = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16552940);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setColor("0;123;255");
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x11815dc
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects3Objects = Hashtable.newFrom({"player_effects_circular_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3});gdjs._22330_26223_95G1_9503Code.eventsList0xcbdd0c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20591316);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595circular_9595001Objects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3[i].setColor("197;0;56");
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xcbdd0c
gdjs._22330_26223_95G1_9503Code.eventsList0xb17854 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xc6131c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x11815dc(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) == 2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xcbdd0c(runtimeScene);} //End of subevents
}

}


{


{
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb17854
gdjs._22330_26223_95G1_9503Code.eventsList0xd5fc04 = function(runtimeScene) {

{



}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xcde83c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xa4dbec(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariables().getFromIndex(0)) == 2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x89533c(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects3.createFrom(runtimeScene.getObjects("Border_collision"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects3Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xb68bac(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.createFrom(runtimeScene.getObjects("Destructible_walls"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xb17854(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xd5fc04
gdjs._22330_26223_95G1_9503Code.eventsList0xb83fe4 = function(runtimeScene) {

{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2[i].getScaleY() <= 0.2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb83fe4
gdjs._22330_26223_95G1_9503Code.eventsList0xbb9ec4 = function(runtimeScene) {

{


{
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xbb9ec4
gdjs._22330_26223_95G1_9503Code.eventsList0x11bb1ec = function(runtimeScene) {

{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[i].getParticleAlpha1() <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.length = k;for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[i].getParticleAlpha1() <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.length = k;for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[i].getParticleAlpha1() <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[i].deleteFromScene(runtimeScene);
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x11bb1ec
gdjs._22330_26223_95G1_9503Code.eventsList0xc783a4 = function(runtimeScene) {

{



}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(0)) >= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xbdbd34(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(1)) >= 301 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xd5fc04(runtimeScene);} //End of subevents
}

}


{



}


{


{
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2.createFrom(runtimeScene.getObjects("player_yuan"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2[i].setScale(gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2[i].getScale() - (0.08));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2[i].setOpacity(gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2[i].getOpacity() - (30));
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xb83fe4(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2.createFrom(runtimeScene.getObjects("player_effects_circular_001"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2[i].hasAnimationEnded() ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xbb9ec4(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(1)) <= 300 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.createFrom(runtimeScene.getObjects("player_starlight_Red"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.createFrom(runtimeScene.getObjects("player_starlight_blue"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.createFrom(runtimeScene.getObjects("player_starlight_yellow"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[i].setParticleAlpha1(gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[i].getParticleAlpha1() - (8));
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[i].setParticleAlpha1(gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[i].getParticleAlpha1() - (8));
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[i].setParticleAlpha1(gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[i].getParticleAlpha1() - (8));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[i].setParticleSize1(gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2[i].getParticleSize1() - (3));
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[i].setParticleSize1(gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2[i].getParticleSize1() - (3));
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[i].setParticleSize1(gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2[i].getParticleSize1() - (3));
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x11bb1ec(runtimeScene);} //End of subevents
}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects1.createFrom(runtimeScene.getObjects("Feather_particle"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects1[i].setFlow(5);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xc783a4
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595mouse_9595positionObjects2Objects = Hashtable.newFrom({"player_mouse_position": gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2});gdjs._22330_26223_95G1_9503Code.eventsList0xa048ec = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10148164);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(4)).setNumber(1);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xa048ec
gdjs._22330_26223_95G1_9503Code.eventsList0x114b444 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.length = 0;

{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(5)).setNumber(1);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595mouse_9595positionObjects2Objects, gdjs.evtTools.input.getMouseX(runtimeScene, "player", 0), gdjs.evtTools.input.getMouseY(runtimeScene, "player", 0), "player");
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xa048ec(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x114b444
gdjs._22330_26223_95G1_9503Code.eventsList0x8c11f4 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) > 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x114b444(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x8c11f4
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595mouse_9595positionObjects2Objects = Hashtable.newFrom({"player_mouse_position": gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595moveObjects2Objects = Hashtable.newFrom({"player_move": gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects2Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2, "Border_collision": gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects2, "Blue_Rune_01": gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects2, "Red_Rune_01": gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects2Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2, "Border_collision": gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects2, "Blue_Rune_01": gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects2, "Red_Rune_01": gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2});gdjs._22330_26223_95G1_9503Code.eventsList0xea71c4 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonPressed(runtimeScene, "Left");
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(1)).setNumber(1200);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(2)).setNumber(60);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xea71c4
gdjs._22330_26223_95G1_9503Code.eventsList0x87fc54 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7026636);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].getVariables().getFromIndex(1)).setNumber(300);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].clearForces();
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].addPolarForce((gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].getAngle()), (gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].getVariables().getFromIndex(1))), 1);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x87fc54
gdjs._22330_26223_95G1_9503Code.eventsList0xd323ac = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.createFrom(runtimeScene.getObjects("player_mouse_position"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2[i].hide();
}
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) <= 0;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x8c11f4(runtimeScene);} //End of subevents
}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 0.05, "鼠标");
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.createFrom(runtimeScene.getObjects("player_mouse_position"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "鼠标");
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.createFrom(runtimeScene.getObjects("player_mouse_position"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.pickedObjectsCount(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595mouse_9595positionObjects2Objects) > 1;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2 */
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].rotateTowardPosition((( gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2[0].getPointY("")), 0, runtimeScene);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(4)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].clearForces();
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].addPolarForce((gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getAngle()), (gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(1))), 0);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects2.createFrom(runtimeScene.getObjects("Blue_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects2.createFrom(runtimeScene.getObjects("Border_collision"));
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.createFrom(runtimeScene.getObjects("Destructible_walls"));
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2.createFrom(runtimeScene.getObjects("Red_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595moveObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects2Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(4)).setNumber(0);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getBehavior("Bounce").BounceOff(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects2Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].setAngle((gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getAverageForce().getAngle()));
}
}}

}


{



}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(5)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(0)).add(1);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(5)) == 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(0)) >= 15 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xea71c4(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(0)) >= 20 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(5)).setNumber(0);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(2)).sub(1);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].getVariables().getFromIndex(2)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x87fc54(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xd323ac
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects2Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2, "Border_collision": gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects2, "Blue_Rune_01": gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects2, "Red_Rune_01": gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2});gdjs._22330_26223_95G1_9503Code.eventsList0xe399a4 = function(runtimeScene) {

{



}


{

gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects2.createFrom(runtimeScene.getObjects("Blue_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects2.createFrom(runtimeScene.getObjects("Border_collision"));
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.createFrom(runtimeScene.getObjects("Destructible_walls"));
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2.createFrom(runtimeScene.getObjects("Red_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects2Objects, false, runtimeScene, false);
}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12304260);
}
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(2)).setNumber(1);
}
}{gdjs.evtTools.sound.playSound(runtimeScene, "player_pengqiang.wav", false, 10, 1);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xe399a4
gdjs._22330_26223_95G1_9503Code.eventsList0xf27a5c = function(runtimeScene) {

{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects2 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(1)) >= 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(1)).sub(0.08);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf27a5c
gdjs._22330_26223_95G1_9503Code.eventsList0x1026714 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariables().getFromIndex(1)) <= 2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getVariables().getFromIndex(1)).add(0.08);
}
}}

}


{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects2 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(1)) >= 2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1026714
gdjs._22330_26223_95G1_9503Code.eventsList0x1172e24 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(1)) >= 301 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xe399a4(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(2)) == 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf27a5c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(2)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x1026714(runtimeScene);} //End of subevents
}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));
{gdjs.evtTools.camera.setCameraZoom(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[0].getVariables()).getFromIndex(1))), "遮罩", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[0].getVariables()).getFromIndex(1))), "player", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[0].getVariables()).getFromIndex(1))), "enemy", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[0].getVariables()).getFromIndex(1))), "碰撞物", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[0].getVariables()).getFromIndex(1))), "背景", 0);
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[i].getVariables().getFromIndex(1)) <= 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[i].getVariables().getFromIndex(1)).setNumber(1);
}
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "遮罩", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "player", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "enemy", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "碰撞物", 0);
}{gdjs.evtTools.camera.setCameraZoom(runtimeScene, 1, "背景", 0);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1172e24
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects2Objects = Hashtable.newFrom({"Red_Rune_01": gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects1Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects1});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects1Objects = Hashtable.newFrom({"Blue_Rune_01": gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects1});gdjs._22330_26223_95G1_9503Code.eventsList0xd115ec = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2.createFrom(runtimeScene.getObjects("Red_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects2Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects2.createFrom(runtimeScene.getObjects("UI_player"));
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getVariables().getFromIndex(0)).setNumber(2);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].setAnimation(2);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects2[i].setAnimation(2);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects1.createFrom(runtimeScene.getObjects("Blue_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects1.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects1Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects1Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects1.createFrom(runtimeScene.getObjects("UI_player"));
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects1 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[i].getVariables().getFromIndex(0)).setNumber(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects1[i].setAnimation(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects1[i].setAnimation(1);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xd115ec
gdjs._22330_26223_95G1_9503Code.eventsList0xed9d7c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1.5, "UI_HP");
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1);

{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)).sub(0.1);
}
}{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "UI_HP");
}}

}


{


{
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xed9d7c
gdjs._22330_26223_95G1_9503Code.eventsList0xcc298c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) >= 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) <= 0;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xed9d7c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xcc298c
gdjs._22330_26223_95G1_9503Code.eventsList0x6817dc = function(runtimeScene) {

{


{
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i].setScaleX((gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i].getVariables().getFromIndex(0))));
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xcc298c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x6817dc
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595SiWangObjects3Objects = Hashtable.newFrom({"player_SiWang": gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595siwang_9595001Objects3Objects = Hashtable.newFrom({"player_effects_siwang_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects3});gdjs._22330_26223_95G1_9503Code.eventsList0xb2a794 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20270324);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects3.createFrom(runtimeScene.getObjects("player_shadow"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects3.length = 0;

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects3.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595SiWangObjects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("")), "player");
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595siwang_9595001Objects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].hide();
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects3[i].hide();
}
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12026980);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Si_Wang.ogg", false, 100, 1);
}}

}


{


{
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb2a794
gdjs._22330_26223_95G1_9503Code.eventsList0xb2a6c4 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].clearForces();
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xb2a794(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1.createFrom(runtimeScene.getObjects("player_effects_siwang_001"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1[i].hasAnimationEnded() ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb2a6c4
gdjs._22330_26223_95G1_9503Code.eventsList0xd374c4 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(11705172);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xd374c4
gdjs._22330_26223_95G1_9503Code.eventsList0xf38234 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12386372);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf38234
gdjs._22330_26223_95G1_9503Code.eventsList0xb87db4 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(1)) >= 180 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xd374c4(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(1)) <= 60 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf38234(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(1)).sub(2);
}
}}

}


{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[i].getVariables().getFromIndex(1)).add(2);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb87db4
gdjs._22330_26223_95G1_9503Code.eventsList0x1356c14 = function(runtimeScene) {

{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2.createFrom(runtimeScene.getObjects("Red_Rune_light"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[i].setOpacity((gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[i].getVariables().getFromIndex(1))));
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xb87db4(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1356c14
gdjs._22330_26223_95G1_9503Code.eventsList0xf9454c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12432804);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf9454c
gdjs._22330_26223_95G1_9503Code.eventsList0x11f823c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(18347324);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x11f823c
gdjs._22330_26223_95G1_9503Code.eventsList0x1202094 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.createFrom(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(1)) >= 180 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf9454c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.createFrom(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(1)) <= 60 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x11f823c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.createFrom(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(1)).sub(2);
}
}}

}


{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1[k] = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1[i].getVariables().getFromIndex(1)).add(2);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1202094
gdjs._22330_26223_95G1_9503Code.eventsList0x135994c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1.createFrom(runtimeScene.getObjects("Blue_Rune_light"));
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects1.createFrom(runtimeScene.getObjects("Red_Rune_light"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1[i].setOpacity((gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects1[0].getVariables()).getFromIndex(1))));
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x1202094(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x135994c
gdjs._22330_26223_95G1_9503Code.eventsList0xc0f2dc = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.createFrom(runtimeScene.getObjects("Blue_Rune_light"));
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2.createFrom(runtimeScene.getObjects("Red_Rune_light"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2[i].setBlendMode(1);
}
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("红色符文石的背后光亮"); }gdjs._22330_26223_95G1_9503Code.eventsList0x1356c14(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("红色符文石的背后光亮"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("蓝色符文石的背后光亮"); }gdjs._22330_26223_95G1_9503Code.eventsList0x135994c(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("蓝色符文石的背后光亮"); }
}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xc0f2dc
gdjs._22330_26223_95G1_9503Code.eventsList0xccfe54 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10730540);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.random(6));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomFloatInRange(1.5, 2));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xccfe54
gdjs._22330_26223_95G1_9503Code.eventsList0x6acc5c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(19956124);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.random(6));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomFloatInRange(1.5, 2));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x6acc5c
gdjs._22330_26223_95G1_9503Code.eventsList0xb37084 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10503876);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].clearForces();
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb37084
gdjs._22330_26223_95G1_9503Code.eventsList0xf39bbc = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(19915236);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1[i].clearForces();
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf39bbc
gdjs._22330_26223_95G1_9503Code.eventsList0x10f587c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].setBlendMode(2);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.random(6));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomFloatInRange(1.5, 2));
}
}}

}


{


{
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].setScale((gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(2))));
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getX() <= -(500) ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xccfe54(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getX() >= 1800 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(1)).setNumber(1);
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x6acc5c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(1)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2[i].addForce(gdjs.randomInRange(-(30), -(60)), 0, 0);
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xb37084(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1.createFrom(runtimeScene.getObjects("smoke_01"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1[i].getVariables().getFromIndex(1)) == 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1[k] = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1[i].addForce(gdjs.randomInRange(30, 60), 0, 0);
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf39bbc(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x10f587c
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects1Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects1, "Border_collision": gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects1, "Blue_Rune_01": gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects1, "Red_Rune_01": gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects1});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects1Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects1, "Border_collision": gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects1, "Blue_Rune_01": gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects1, "Red_Rune_01": gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects1});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects2Objects = Hashtable.newFrom({"E_Red_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects2, "E_Blue_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects5Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects5});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects5Objects = Hashtable.newFrom({"E_Blue_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects5});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects5Objects = Hashtable.newFrom({"E_Blue_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects5});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects4Objects = Hashtable.newFrom({"E_Red_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects4});gdjs._22330_26223_95G1_9503Code.eventsList0x112f5dc = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects5.createFrom(gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayerObjects5.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects4);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects5Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects5Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects5 */
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3);

{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5[i].getBehavior("Bounce").BounceOff(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects5Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects2);

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects4 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects4Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects4Objects, false, runtimeScene, false);
}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10533188);
}
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4[i].getVariables().getFromIndex(0)).sub(0.2);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x112f5dc
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects4Objects = Hashtable.newFrom({"E_Red_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects4Objects = Hashtable.newFrom({"E_Red_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects3Objects = Hashtable.newFrom({"E_Blue_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects3});gdjs._22330_26223_95G1_9503Code.eventsList0xf76954 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects4Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects4Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects4 */
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3);

{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[i].getBehavior("Bounce").BounceOff(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects4Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{



}


{

gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2);

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects3 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects3Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3[i].getVariables().getFromIndex(0)).sub(0.2);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf76954
gdjs._22330_26223_95G1_9503Code.eventsList0xbbc42c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i].getAnimation() == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects4[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x112f5dc(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getAnimation() == 2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf76954(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xbbc42c
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects4Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects4Objects = Hashtable.newFrom({"E_Blue_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemy_9595SiWangObjects4Objects = Hashtable.newFrom({"E_Blue_enemy_SiWang": gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects4});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595enemy_9595001Objects5Objects = Hashtable.newFrom({"player_effects_enemy_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects5});gdjs._22330_26223_95G1_9503Code.eventsList0xb694c4 = function(runtimeScene) {

{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(7023916);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects5.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595enemy_9595001Objects5Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects5.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects5[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects5.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects5[i].setOpacity(200);
}
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20540620);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects5.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects5.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects5[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects5[i].getVariables().getFromIndex(0)).add(0.1);
}
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10442780);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).add(1);
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12012612);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "enemy_siwang.wav", false, 20, 1);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb694c4
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects3Objects = Hashtable.newFrom({"E_Red_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3});gdjs._22330_26223_95G1_9503Code.eventsList0xa3e784 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects3);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects4Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects4Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4 */
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects4.length = 0;

{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemy_9595SiWangObjects4Objects, (( gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4[0].getPointY("")), "enemy");
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xb694c4(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects2);

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects3 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects3Objects, false, runtimeScene, false);
}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20504668);
}
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3[i].getVariables().getFromIndex(0)).sub(0.2);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xa3e784
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects3Objects = Hashtable.newFrom({"E_Red_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemy_9595SiWangObjects3Objects = Hashtable.newFrom({"E_Red_enemy_SiWang": gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595enemy_9595001Objects4Objects = Hashtable.newFrom({"player_effects_enemy_001": gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects4});gdjs._22330_26223_95G1_9503Code.eventsList0xe925b4 = function(runtimeScene) {

{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17780540);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects4.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayer_9595effects_9595enemy_9595001Objects4Objects, (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4[0].getPointY("")), "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects4[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects4[i].setOpacity(200);
}
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20540852);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4[i].getVariables().getFromIndex(0)).add(0.1);
}
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10801108);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(3).add(1);
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15924996);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "enemy_siwang.wav", false, 20, 1);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xe925b4
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects2Objects = Hashtable.newFrom({"E_Blue_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2});gdjs._22330_26223_95G1_9503Code.eventsList0x11162d4 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects2);

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects3Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3 */
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects3.length = 0;

{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3[i].deleteFromScene(runtimeScene);
}
}{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemy_9595SiWangObjects3Objects, (( gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3[0].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3[0].getPointY("")), "enemy");
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xe925b4(runtimeScene);} //End of subevents
}

}


{



}


{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects2 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects2Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)).sub(0.2);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x11162d4
gdjs._22330_26223_95G1_9503Code.eventsList0x134288c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayerObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].getAnimation() == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xa3e784(runtimeScene);} //End of subevents
}

}


{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayerObjects2 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i].getAnimation() == 2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayerObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x11162d4(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x134288c
gdjs._22330_26223_95G1_9503Code.eventsList0xf7db64 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i].getVariables().getFromIndex(1)) <= 301 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xbbc42c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].getVariables().getFromIndex(1)) >= 301 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x134288c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf7db64
gdjs._22330_26223_95G1_9503Code.eventsList0xbb89dc = function(runtimeScene) {

{


{
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xbb89dc
gdjs._22330_26223_95G1_9503Code.eventsList0x13937b4 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2.createFrom(runtimeScene.getObjects("E_Blue_enemy"));
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects2.createFrom(runtimeScene.getObjects("E_Red_enemy"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects2ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf7db64(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2.createFrom(runtimeScene.getObjects("player_effects_enemy_001"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2[i].hasAnimationEnded() ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xbb89dc(runtimeScene);} //End of subevents
}

}


{


{
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x13937b4
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects1Objects = Hashtable.newFrom({"E_Blue_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects1Objects = Hashtable.newFrom({"E_Red_enemy": gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1});gdjs._22330_26223_95G1_9503Code.eventsList0x89b42c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.timerElapsedTime(runtimeScene, 1, "开始时间");
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.resetTimer(runtimeScene, "开始时间");
}{runtimeScene.getVariables().getFromIndex(0).sub(1);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x89b42c
gdjs._22330_26223_95G1_9503Code.eventsList0xe83844 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3.createFrom(runtimeScene.getObjects("B_Scene_crossing"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3[i].getOpacity() > 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3[i].setOpacity(gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3[i].getOpacity() - (5));
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.createFrom(runtimeScene.getObjects("B_Scene_crossing"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].getOpacity() <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].setOpacity(0);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xe83844
gdjs._22330_26223_95G1_9503Code.eventsList0x9ab074 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(7)) == 0;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xe83844(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x9ab074
gdjs._22330_26223_95G1_9503Code.eventsList0xe3e38c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.createFrom(runtimeScene.getObjects("B_Scene_crossing"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].getOpacity() <= 100 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x89b42c(runtimeScene);} //End of subevents
}

}


{



}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) > 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x9ab074(runtimeScene);} //End of subevents
}

}


{


{
}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) <= 0;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.createFrom(runtimeScene.getObjects("UI_kaishi_time"));
{runtimeScene.getVariables().getFromIndex(0).setNumber(0);
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1[i].hide();
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xe3e38c
gdjs._22330_26223_95G1_9503Code.eventsList0xb21b54 = function(runtimeScene) {

{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) < 0.6 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].setColor("255;144;2");
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb21b54
gdjs._22330_26223_95G1_9503Code.eventsList0xed1b4c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2.createFrom(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) < (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2[0].getVariables()).getFromIndex(0))) ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2[i].getVariables().getFromIndex(0)).sub(0.004);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.createFrom(runtimeScene.getObjects("UI_Violet_04"));
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i].getVariables().getFromIndex(0)) > (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1[0].getVariables()).getFromIndex(0))) ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1 */
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1[i].getVariables().getFromIndex(0)).setNumber((gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[0].getVariables()).getFromIndex(0))));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xed1b4c
gdjs._22330_26223_95G1_9503Code.eventsList0x1172c74 = function(runtimeScene) {

{



}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) > 0.6 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].setColor("252;252;252");
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) > 0.4 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xb21b54(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) < 0.6 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].setColor("255;82;2");
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) < 0.4 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].setColor("255;2;2");
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04_01"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2[i].setBlendMode(1);
}
}}

}


{


{
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1.createFrom(runtimeScene.getObjects("UI_Violet_04_01"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1[i].setScaleX((gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1[i].getVariables().getFromIndex(0))));
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xed1b4c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1172c74
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDB_9595ChuanSongMen_9595001Objects2Objects = Hashtable.newFrom({"B_ChuanSongMen_001": gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2});gdjs._22330_26223_95G1_9503Code.eventsList0xa43f4c = function(runtimeScene) {

{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15363684);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "Sheng_Li.ogg", false, 50, 1);
}}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(14900764);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(16895804);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDB_9595ChuanSongMen_9595001Objects2Objects, 608, 383.5, "player");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2[i].setScale(0.5);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2[i].setZOrder(0);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xa43f4c
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDB_9595ChuanSongMen_9595001Objects2Objects = Hashtable.newFrom({"B_ChuanSongMen_001": gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2});gdjs._22330_26223_95G1_9503Code.eventsList0xb16324 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(1)) <= 0;
}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(2)) <= 0;
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xa43f4c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2.createFrom(runtimeScene.getObjects("B_ChuanSongMen_001"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDB_9595ChuanSongMen_9595001Objects2Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.createFrom(runtimeScene.getObjects("player_move"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2[i].clearForces();
}
}{runtimeScene.getVariables().getFromIndex(7).setNumber(1);
}}

}


{



}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb16324
gdjs._22330_26223_95G1_9503Code.eventsList0xf47d94 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2.createFrom(runtimeScene.getObjects("B_Red_Warning_Mask_02"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2[i].setOpacity(110);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2[i].hide();
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) > 0.4 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2.createFrom(runtimeScene.getObjects("B_Red_Warning_Mask_02"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2[i].hide();
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)) <= 0.4 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = k;}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20541740);
}
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2.createFrom(runtimeScene.getObjects("B_Red_Warning_Mask_02"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2[i].hide(false);
}
}}

}


{


{
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects1.createFrom(runtimeScene.getObjects("B_Red_Warning_Mask_02"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects1[i].getBehavior("Flash").Flash(0.1, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf47d94
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects3Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3});gdjs._22330_26223_95G1_9503Code.eventsList0x702eec = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20325604);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariables().getFromIndex(0)).sub(4);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x702eec
gdjs._22330_26223_95G1_9503Code.eventsList0x119eb2c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.createFrom(runtimeScene.getObjects("Destructible_walls"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects3Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x702eec(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x119eb2c
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2});gdjs._22330_26223_95G1_9503Code.eventsList0x130b144 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(17777468);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[i].getVariables().getFromIndex(0)).sub(1);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x130b144
gdjs._22330_26223_95G1_9503Code.eventsList0x1171b14 = function(runtimeScene) {

{



}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.createFrom(runtimeScene.getObjects("Destructible_walls"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariables().getFromIndex(0)) == 4 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].setAnimation(0);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.createFrom(runtimeScene.getObjects("Destructible_walls"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariables().getFromIndex(0)) == 3 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].setAnimation(1);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.createFrom(runtimeScene.getObjects("Destructible_walls"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariables().getFromIndex(0)) == 2 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].setAnimation(2);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.createFrom(runtimeScene.getObjects("Destructible_walls"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].setAnimation(3);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.createFrom(runtimeScene.getObjects("Destructible_walls"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariables().getFromIndex(0)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i].getVariables().getFromIndex(1)) >= 301 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x119eb2c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.createFrom(runtimeScene.getObjects("Destructible_walls"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects2Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x130b144(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1171b14
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595walls_9595FractureObjects6Objects = Hashtable.newFrom({"Destructible_walls_Fracture": gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6});gdjs._22330_26223_95G1_9503Code.eventsList0x130697c = function(runtimeScene) {

{


{
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects6.createFrom(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3);

gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6.length = 0;

{gdjs.evtTools.object.createObjectOnScene((typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : runtimeScene), gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595walls_9595FractureObjects6Objects, (( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects6.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects6[0].getPointX("sui_shi")), (( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects6.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects6[0].getPointY("sui_shi")), "enemy");
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6[i].setAnimation(gdjs.random(3));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6[i].addPolarForce(gdjs.randomFloat(360), 300, 1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6[i].setScale(gdjs.randomFloatInRange(0.7, 1.3));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x130697c
gdjs._22330_26223_95G1_9503Code.eventsList0x133f5f4 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.repeatCount5 = gdjs.randomInRange(4, 8);
for(gdjs._22330_26223_95G1_9503Code.repeatIndex5 = 0;gdjs._22330_26223_95G1_9503Code.repeatIndex5 < gdjs._22330_26223_95G1_9503Code.repeatCount5;++gdjs._22330_26223_95G1_9503Code.repeatIndex5) {

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(19950084);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val)
{

{ //Subevents: 
gdjs._22330_26223_95G1_9503Code.eventsList0x130697c(runtimeScene);} //Subevents end.
}
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x133f5f4
gdjs._22330_26223_95G1_9503Code.eventsList0x12fed4c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3.createFrom(gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3[i].getOpacity() <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3[i].deleteFromScene(runtimeScene);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x12fed4c
gdjs._22330_26223_95G1_9503Code.eventsList0x139e144 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.createFrom(runtimeScene.getObjects("Destructible_walls"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[i].getVariables().getFromIndex(0)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.length = k;}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20324556);
}
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[i].getVariables().getFromIndex(1)).setNumber(gdjs.randomInRange(4, 8));
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.createFrom(runtimeScene.getObjects("Destructible_walls"));

for(gdjs._22330_26223_95G1_9503Code.forEachIndex3 = 0;gdjs._22330_26223_95G1_9503Code.forEachIndex3 < gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.length;++gdjs._22330_26223_95G1_9503Code.forEachIndex3) {
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length = 0;


gdjs._22330_26223_95G1_9503Code.forEachTemporary3 = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2[gdjs._22330_26223_95G1_9503Code.forEachIndex3];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.push(gdjs._22330_26223_95G1_9503Code.forEachTemporary3);
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i].getVariables().getFromIndex(0)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents: 
gdjs._22330_26223_95G1_9503Code.eventsList0x133f5f4(runtimeScene);} //Subevents end.
}
}

}


{

gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects1.createFrom(runtimeScene.getObjects("Destructible_walls_Fracture"));

for(gdjs._22330_26223_95G1_9503Code.forEachIndex2 = 0;gdjs._22330_26223_95G1_9503Code.forEachIndex2 < gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects1.length;++gdjs._22330_26223_95G1_9503Code.forEachIndex2) {
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2.length = 0;


gdjs._22330_26223_95G1_9503Code.forEachTemporary2 = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects1[gdjs._22330_26223_95G1_9503Code.forEachIndex2];
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2.push(gdjs._22330_26223_95G1_9503Code.forEachTemporary2);
if (true) {
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2[i].setOpacity(gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2[i].getOpacity() - (5));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2[i].setScale(gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2[i].getScale() - (0.01));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2[i].rotate(gdjs.random(360), runtimeScene);
}
}
{ //Subevents: 
gdjs._22330_26223_95G1_9503Code.eventsList0x12fed4c(runtimeScene);} //Subevents end.
}
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x139e144
gdjs._22330_26223_95G1_9503Code.eventsList0x1171a64 = function(runtimeScene) {

{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("与player碰撞删除"); }gdjs._22330_26223_95G1_9503Code.eventsList0x1171b14(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("与player碰撞删除"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("创建随机的破碎石头"); }gdjs._22330_26223_95G1_9503Code.eventsList0x139e144(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("创建随机的破碎石头"); }
}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1171a64
gdjs._22330_26223_95G1_9503Code.eventsList0x117dc8c = function(runtimeScene) {

{


{
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].setPosition((gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(0))),(gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(1))));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x117dc8c
gdjs._22330_26223_95G1_9503Code.eventsList0x13888bc = function(runtimeScene) {

{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.createFrom(runtimeScene.getObjects("player_follow"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(runtimeScene.getObjects("player_move"));
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects3.createFrom(runtimeScene.getObjects("player_shadow"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects3[i].setPosition((( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("xia")),(( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("xia")));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayerObjects3[i].setPosition((( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("xia")),(( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("xia")));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(0)).setNumber(gdjs.evtTools.common.lerp((gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getPointX("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointX("")), 0.1));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(1)).setNumber(gdjs.evtTools.common.lerp((gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getPointY("")), (( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length === 0 ) ? 0 :gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[0].getPointY("")), 0.1));
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x117dc8c(runtimeScene);} //End of subevents
}

}


{


{
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.createFrom(runtimeScene.getObjects("player_follow"));
{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length !== 0 ? gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[0] : null), true, "遮罩", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length !== 0 ? gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[0] : null), true, "player", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length !== 0 ? gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[0] : null), true, "enemy", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length !== 0 ? gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[0] : null), true, "碰撞物", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length !== 0 ? gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[0] : null), true, "背景", 0);
}{gdjs.evtTools.camera.centerCamera(runtimeScene, (gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length !== 0 ? gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[0] : null), true, "", 0);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x13888bc
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects3});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects3ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects3ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects3ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects3Objects = Hashtable.newFrom({"Destructible_walls": gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3, "Border_collision": gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects3, "Blue_Rune_01": gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects3, "Red_Rune_01": gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects3});gdjs._22330_26223_95G1_9503Code.eventsList0x13a2b64 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects3.createFrom(runtimeScene.getObjects("Blue_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects3.createFrom(runtimeScene.getObjects("Border_collision"));
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.createFrom(runtimeScene.getObjects("Destructible_walls"));
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects3.createFrom(runtimeScene.getObjects("Red_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects3Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects3ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects3ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects3ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects3Objects, false, runtimeScene, false);
}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(18749092);
}
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.createFrom(runtimeScene.getObjects("player_follow"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(2)).setNumber(30);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x13a2b64
gdjs._22330_26223_95G1_9503Code.eventsList0x138ae8c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3);


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[i].getVariables().getFromIndex(3)) > 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[i].getVariables().getFromIndex(3)).sub(0.3);
}
}}

}


{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(3)) < 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(3)).add(0.3);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x138ae8c
gdjs._22330_26223_95G1_9503Code.eventsList0x11f7084 = function(runtimeScene) {

{


{
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3);

{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[i].getVariables().getFromIndex(3)).setNumber(gdjs.randomFloatInRange(-(1.6), 1.6));
}
}}

}


{


{
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.createFrom(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3);

{gdjs.evtTools.camera.setCameraRotation(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[0].getVariables()).getFromIndex(3))), "背景", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[0].getVariables()).getFromIndex(3))), "碰撞物", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[0].getVariables()).getFromIndex(3))), "enemy", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[0].getVariables()).getFromIndex(3))), "player", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, (gdjs.RuntimeObject.getVariableNumber(((gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4[0].getVariables()).getFromIndex(3))), "遮罩", 0);
}}

}


{

/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3 */

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(3)) != 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x138ae8c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x11f7084
gdjs._22330_26223_95G1_9503Code.eventsList0x11ffd3c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.createFrom(runtimeScene.getObjects("player_follow"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(2)).sub(1);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.createFrom(runtimeScene.getObjects("player_follow"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(2)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(2)).setNumber(0);
}
}}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.createFrom(runtimeScene.getObjects("player_move"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i].getVariables().getFromIndex(1)) >= 301 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x13a2b64(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.createFrom(runtimeScene.getObjects("player_follow"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i].getVariables().getFromIndex(2)) > 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x11f7084(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.createFrom(runtimeScene.getObjects("player_follow"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[i].getVariables().getFromIndex(2)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{gdjs.evtTools.camera.setCameraRotation(runtimeScene, 0, "背景", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, 0, "碰撞物", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, 0, "enemy", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, 0, "player", 0);
}{gdjs.evtTools.camera.setCameraRotation(runtimeScene, 0, "遮罩", 0);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x11ffd3c
gdjs._22330_26223_95G1_9503Code.eventsList0x1362f04 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects1.createFrom(runtimeScene.getObjects("player_follow"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects1[i].setPosition(gdjs.evtTools.common.clamp((gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects1[i].getVariables().getFromIndex(0))), 450, 766),gdjs.evtTools.common.clamp((gdjs.RuntimeObject.getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects1[i].getVariables().getFromIndex(1))), 210, 557));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1362f04
gdjs._22330_26223_95G1_9503Code.eventsList0x1340be4 = function(runtimeScene) {

{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("镜头跟随"); }gdjs._22330_26223_95G1_9503Code.eventsList0x13888bc(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("镜头跟随"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("屏幕抖动"); }gdjs._22330_26223_95G1_9503Code.eventsList0x11ffd3c(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("屏幕抖动"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("镜头限制在特定的范围内"); }gdjs._22330_26223_95G1_9503Code.eventsList0x1362f04(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("镜头限制在特定的范围内"); }
}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1340be4
gdjs._22330_26223_95G1_9503Code.eventsList0x13055bc = function(runtimeScene) {

{


{
/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3[i].addForce(0, 200, 1);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x13055bc
gdjs._22330_26223_95G1_9503Code.eventsList0xc0dec4 = function(runtimeScene) {

{


{
/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2[i].addForce(0, -(200), 1);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xc0dec4
gdjs._22330_26223_95G1_9503Code.eventsList0xf99f04 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3.createFrom(runtimeScene.getObjects("E_gear"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3[i].getY() <= 100 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3[k] = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3[i].clearForces();
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x13055bc(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.createFrom(runtimeScene.getObjects("E_gear"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2[i].getY() >= 660 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2[i].clearForces();
}
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xc0dec4(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf99f04
gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects = Hashtable.newFrom({"player": gdjs._22330_26223_95G1_9503Code.GDplayerObjects2});gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595gearObjects2Objects = Hashtable.newFrom({"E_gear": gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2});gdjs._22330_26223_95G1_9503Code.eventsList0xf4801c = function(runtimeScene) {

{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20546068);
}
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.createFrom(runtimeScene.getObjects("UI_Violet_04"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].returnVariable(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2[i].getVariables().getFromIndex(0)).sub(0.2);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf4801c
gdjs._22330_26223_95G1_9503Code.eventsList0x130712c = function(runtimeScene) {

{


{
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.createFrom(runtimeScene.getObjects("E_gear"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2[i].rotate(400, runtimeScene);
}
}}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) <= 0;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf99f04(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.createFrom(runtimeScene.getObjects("E_gear"));
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.createFrom(runtimeScene.getObjects("player"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.object.hitBoxesCollisionTest(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDplayerObjects2Objects, gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595gearObjects2Objects, false, runtimeScene, false);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf4801c(runtimeScene);} //End of subevents
}

}


{


{
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x130712c
gdjs._22330_26223_95G1_9503Code.eventsList0x1397e0c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.createFrom(runtimeScene.getObjects("B_Scene_crossing"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].getOpacity() < 255 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].setOpacity(gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].getOpacity() + (5));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1397e0c
gdjs._22330_26223_95G1_9503Code.eventsList0x136280c = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) >= 100;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).setNumber(100);
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x1397e0c(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x136280c
gdjs._22330_26223_95G1_9503Code.eventsList0xa01334 = function(runtimeScene) {

{


{
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects2.createFrom(runtimeScene.getObjects("UI_Game_over"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects2[i].getBehavior("Tween").addObjectPositionYTween("移动中间", 190, "swingTo", 800, false);
}
}}

}


{


{
{runtimeScene.getVariables().getFromIndex(6).add(1);
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x136280c(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1.createFrom(runtimeScene.getObjects("B_Scene_crossing"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1[i].getOpacity() >= 250 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1[k] = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "场景_G1_03", false);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xa01334
gdjs._22330_26223_95G1_9503Code.eventsList0x1397f34 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i].getVariables().getFromIndex(0)) <= 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xa01334(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x1397f34
gdjs._22330_26223_95G1_9503Code.eventsList0x119d024 = function(runtimeScene) {

{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1.createFrom(runtimeScene.getObjects("UI_guan_ka_zhi"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1[i].setOutline("46;1;1", 12);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1[i].setShadow("34;16;16", 8, 20, 40);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1[i].showShadow(true);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1[i].setPadding(50);
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x119d024
gdjs._22330_26223_95G1_9503Code.eventsList0x11177c4 = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.createFrom(runtimeScene.getObjects("B_Scene_crossing"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].getOpacity() < 255 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[k] = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
/* Reuse gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2 */
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].setOpacity(gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2[i].getOpacity() + (5));
}
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x11177c4
gdjs._22330_26223_95G1_9503Code.eventsList0xf91374 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(6)) >= 50;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).setNumber(50);
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x11177c4(runtimeScene);} //End of subevents
}

}


{

gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1.createFrom(runtimeScene.getObjects("B_Scene_crossing"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1[i].getOpacity() >= 250 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1[k] = gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1.length = k;}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(15533852);
}
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "场景_G1_04", false);
}}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xf91374
gdjs._22330_26223_95G1_9503Code.eventsList0x893fa4 = function(runtimeScene) {

{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(7)) == 1;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(6).add(1);
}
{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0xf91374(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x893fa4
gdjs._22330_26223_95G1_9503Code.eventsList0x135203c = function(runtimeScene) {

{

gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.createFrom(runtimeScene.getObjects("UI_Violet_04"));

gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length;i<l;++i) {
    if ( gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i].getVariableNumber(gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i].getVariables().getFromIndex(0)) > 0 ) {
        gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = true;
        gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[k] = gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1[i];
        ++k;
    }
}
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length = k;}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._22330_26223_95G1_9503Code.eventsList0x893fa4(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0x135203c
gdjs._22330_26223_95G1_9503Code.eventsList0xb5aa0 = function(runtimeScene) {

{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.createFrom(runtimeScene.getObjects("player_move"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].hide();
}
}}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(0)) > 0;
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.createFrom(runtimeScene.getObjects("player_move"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1[i].clearForces();
}
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("粒子"); }gdjs._22330_26223_95G1_9503Code.eventsList0xc783a4(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("粒子"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("player移动、碰撞监测"); }gdjs._22330_26223_95G1_9503Code.eventsList0xd323ac(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("player移动、碰撞监测"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("速度>300的时候，于墙壁碰撞时候+屏幕缩放+碰墙音效"); }gdjs._22330_26223_95G1_9503Code.eventsList0x1172e24(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("速度>300的时候，于墙壁碰撞时候+屏幕缩放+碰墙音效"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("player与符文相碰撞后改变颜色"); }gdjs._22330_26223_95G1_9503Code.eventsList0xd115ec(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("player与符文相碰撞后改变颜色"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("player_HP"); }gdjs._22330_26223_95G1_9503Code.eventsList0x6817dc(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("player_HP"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("Game over+死亡音乐"); }gdjs._22330_26223_95G1_9503Code.eventsList0xb2a6c4(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("Game over+死亡音乐"); }
}


{


{
}

}


{



}


{



}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1.createFrom(runtimeScene.getObjects("B_Red_Warning_Mask_01"));
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects1.createFrom(runtimeScene.getObjects("Border_collision"));
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects1.createFrom(runtimeScene.getObjects("Forest_Tile"));
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1.createFrom(runtimeScene.getObjects("Stone_Frame_Collision_shadow_1"));
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects1.createFrom(runtimeScene.getObjects("Stone_Frame_Collision_shadow_2"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects1[i].setColor("136;136;136");
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1[i].setBlendMode(2);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1[i].setColor("41;144;255");
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects1[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects1[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1[i].setColor("13;50;167");
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1[i].setBlendMode(2);
}
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("蓝色和红色符文石的背后光亮"); }gdjs._22330_26223_95G1_9503Code.eventsList0xc0f2dc(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("蓝色和红色符文石的背后光亮"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("背景烟雾"); }gdjs._22330_26223_95G1_9503Code.eventsList0x10f587c(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("背景烟雾"); }
}


{



}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{



}


{



}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1.createFrom(runtimeScene.getObjects("E_Blue_enemy"));
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1.createFrom(runtimeScene.getObjects("E_Red_enemy"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1[i].addPolarForce(gdjs.randomFloat(360), 100, 1);
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1[i].addPolarForce(gdjs.randomFloat(360), 100, 1);
}
}}

}


{



}


{


{
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects1.createFrom(runtimeScene.getObjects("Blue_Rune_01"));
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects1.createFrom(runtimeScene.getObjects("Border_collision"));
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects1.createFrom(runtimeScene.getObjects("Destructible_walls"));
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1.createFrom(runtimeScene.getObjects("E_Blue_enemy"));
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1.createFrom(runtimeScene.getObjects("E_Red_enemy"));
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects1.createFrom(runtimeScene.getObjects("Red_Rune_01"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1[i].getBehavior("Bounce").BounceOff(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1[i].getBehavior("Bounce").BounceOff(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDDestructible_9595wallsObjects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBorder_9595collisionObjects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDBlue_9595Rune_959501Objects1ObjectsGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDRed_9595Rune_959501Objects1Objects, (typeof eventsFunctionContext !== 'undefined' ? eventsFunctionContext : undefined));
}
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("enemy与player碰撞，增加 UI_Violet_04.HP -=、+= 1，增加圆形特效+死亡音乐"); }gdjs._22330_26223_95G1_9503Code.eventsList0x13937b4(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("enemy与player碰撞，增加 UI_Violet_04.HP -=、+= 1，增加圆形特效+死亡音乐"); }
}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{



}


{



}


{


{
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.createFrom(runtimeScene.getObjects("UI_kaishi_time"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(0)));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1[i].setOutline("46;1;1", 12);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1[i].setShadow("34;16;16", 15, 20, 40);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1[i].showShadow(true);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1[i].setPadding(50);
}
}}

}


{



}


{


{
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1.createFrom(runtimeScene.getObjects("UI_Game_over"));
{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1[i].setOutline("46;1;1", 12);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1[i].setShadow("34;16;16", 15, 20, 40);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1[i].showShadow(true);
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1[i].setPadding(50);
}
}}

}


{



}


{


{
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1.createFrom(runtimeScene.getObjects("E_Blue_enemy"));
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1.createFrom(runtimeScene.getObjects("E_Red_enemy"));
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects1.createFrom(runtimeScene.getObjects("UI_Blue_geshu"));
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects1.createFrom(runtimeScene.getObjects("UI_Red_geshu"));
{runtimeScene.getVariables().getFromIndex(1).setNumber(gdjs.evtTools.object.pickedObjectsCount(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Blue_9595enemyObjects1Objects));
}{runtimeScene.getVariables().getFromIndex(2).setNumber(gdjs.evtTools.object.pickedObjectsCount(gdjs._22330_26223_95G1_9503Code.mapOfGDgdjs_46_9522330_9526223_9595G1_959503Code_46GDE_9595Red_9595enemyObjects1Objects));
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(1)));
}
}{for(var i = 0, len = gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects1.length ;i < len;++i) {
    gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects1[i].setString(gdjs.evtTools.common.getVariableString(runtimeScene.getVariables().getFromIndex(2)));
}
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("场景转场+开始时间<=0"); }gdjs._22330_26223_95G1_9503Code.eventsList0xe3e38c(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("场景转场+开始时间<=0"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("UI条设定"); }gdjs._22330_26223_95G1_9503Code.eventsList0x1172c74(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("UI条设定"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("过关传送门"); }gdjs._22330_26223_95G1_9503Code.eventsList0xb16324(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("过关传送门"); }
}


{



}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("屏幕闪烁"); }gdjs._22330_26223_95G1_9503Code.eventsList0xf47d94(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("屏幕闪烁"); }
}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{



}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("可破坏性石头"); }gdjs._22330_26223_95G1_9503Code.eventsList0x1171a64(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("可破坏性石头"); }
}


{


{
}

}


{



}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("镜头-总"); }gdjs._22330_26223_95G1_9503Code.eventsList0x1340be4(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("镜头-总"); }
}


{



}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
}if ( gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val ) {
{
{gdjs._22330_26223_95G1_9503Code.conditionTrue_1 = gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0;
gdjs._22330_26223_95G1_9503Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(19949140);
}
}}
if (gdjs._22330_26223_95G1_9503Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "场景_G1_03", false);
}}

}


{


gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = false;
{
gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._22330_26223_95G1_9503Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "map\\sound\\Chang_Jing_sound.ogg", true, 40, 1);
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("齿轮"); }gdjs._22330_26223_95G1_9503Code.eventsList0x130712c(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("齿轮"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("场景转场+Game over"); }gdjs._22330_26223_95G1_9503Code.eventsList0x1397f34(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("场景转场+Game over"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("关卡值字体设定"); }gdjs._22330_26223_95G1_9503Code.eventsList0x119d024(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("关卡值字体设定"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("过关转换下一关"); }gdjs._22330_26223_95G1_9503Code.eventsList0x135203c(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("过关转换下一关"); }
}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


}; //End of gdjs._22330_26223_95G1_9503Code.eventsList0xb5aa0


gdjs._22330_26223_95G1_9503Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._22330_26223_95G1_9503Code.GDplayerObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayerObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayerObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayerObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayerObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayerObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayerObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95yuanObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95shadowObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95moveObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95mouse_95positionObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95followObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBorder_95collisionObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95circular_95001Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95enemy_95001Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95yellowObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95effects_95siwang_95001Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95RedObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95starlight_95blueObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Red_95Warning_95Mask_9502Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95lightObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDRed_95Rune_95Lizi_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95lightObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDBlue_95Rune_95Lizi_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95playerObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9504_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9503Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9502Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Violet_9505Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95enemy_95UIObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95enemy_95UIObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95kaishi_95timeObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Game_95overObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Blue_95geshuObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95Red_95geshuObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95Scene_95crossingObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDB_95ChuanSongMen_95001Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDGrassland_95TileObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDLawn_95boxObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDForest_95TileObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFeather_95particleObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95walls_95FractureObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDDestructible_95wallsObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_952Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDStone_95Frame_95Collision_95shadow_951Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDsmoke_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDCactus_9502Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDFLOWERObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_951Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDgrass_952Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9502Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDstone_9503Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDT_95smoke_9501Objects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemyObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemyObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDplayer_95SiWangObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Blue_95enemy_95SiWangObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95Red_95enemy_95SiWangObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDUI_95guan_95ka_95zhiObjects7.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects1.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects2.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects3.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects4.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects5.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects6.length = 0;
gdjs._22330_26223_95G1_9503Code.GDE_95gearObjects7.length = 0;

gdjs._22330_26223_95G1_9503Code.eventsList0xb5aa0(runtimeScene);
return;

}
gdjs['_22330_26223_95G1_9503Code'] = gdjs._22330_26223_95G1_9503Code;
