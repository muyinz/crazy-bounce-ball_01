gdjs._24320_22987_22330_26223Code = {};
gdjs._24320_22987_22330_26223Code.GDplayerObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayerObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayerObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayerObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95yuanObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95yuanObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95yuanObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95yuanObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95shadowObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95shadowObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95shadowObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95shadowObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95moveObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95moveObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95moveObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95moveObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95mouse_95positionObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95mouse_95positionObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95mouse_95positionObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95mouse_95positionObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95followObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95followObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95followObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95followObjects4= [];
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects1= [];
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects2= [];
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects3= [];
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95circular_95001Objects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95circular_95001Objects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95circular_95001Objects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95circular_95001Objects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95enemy_95001Objects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95enemy_95001Objects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95enemy_95001Objects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95enemy_95001Objects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95yellowObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95yellowObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95yellowObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95yellowObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95siwang_95001Objects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95siwang_95001Objects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95siwang_95001Objects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95siwang_95001Objects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95RedObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95RedObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95RedObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95RedObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95blueObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95blueObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95blueObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95blueObjects4= [];
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9502Objects1= [];
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9502Objects2= [];
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9502Objects3= [];
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9502Objects4= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects1= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects4= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95Lizi_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95Lizi_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95Lizi_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95Lizi_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects3= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects4= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95Lizi_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95Lizi_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95Lizi_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95Lizi_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95playerObjects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95playerObjects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95playerObjects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95playerObjects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504Objects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504Objects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504Objects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504Objects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9503Objects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9503Objects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9503Objects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9503Objects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9502Objects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9502Objects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9502Objects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9502Objects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9505Objects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9505Objects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9505Objects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9505Objects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95enemy_95UIObjects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95enemy_95UIObjects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95enemy_95UIObjects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95enemy_95UIObjects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95enemy_95UIObjects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95enemy_95UIObjects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95enemy_95UIObjects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95enemy_95UIObjects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95kaishi_95timeObjects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95kaishi_95timeObjects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95kaishi_95timeObjects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95kaishi_95timeObjects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Game_95overObjects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Game_95overObjects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Game_95overObjects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Game_95overObjects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95geshuObjects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95geshuObjects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95geshuObjects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95geshuObjects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95geshuObjects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95geshuObjects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95geshuObjects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95geshuObjects4= [];
gdjs._24320_22987_22330_26223Code.GDB_95Scene_95crossingObjects1= [];
gdjs._24320_22987_22330_26223Code.GDB_95Scene_95crossingObjects2= [];
gdjs._24320_22987_22330_26223Code.GDB_95Scene_95crossingObjects3= [];
gdjs._24320_22987_22330_26223Code.GDB_95Scene_95crossingObjects4= [];
gdjs._24320_22987_22330_26223Code.GDB_95ChuanSongMen_95001Objects1= [];
gdjs._24320_22987_22330_26223Code.GDB_95ChuanSongMen_95001Objects2= [];
gdjs._24320_22987_22330_26223Code.GDB_95ChuanSongMen_95001Objects3= [];
gdjs._24320_22987_22330_26223Code.GDB_95ChuanSongMen_95001Objects4= [];
gdjs._24320_22987_22330_26223Code.GDGrassland_95TileObjects1= [];
gdjs._24320_22987_22330_26223Code.GDGrassland_95TileObjects2= [];
gdjs._24320_22987_22330_26223Code.GDGrassland_95TileObjects3= [];
gdjs._24320_22987_22330_26223Code.GDGrassland_95TileObjects4= [];
gdjs._24320_22987_22330_26223Code.GDLawn_95boxObjects1= [];
gdjs._24320_22987_22330_26223Code.GDLawn_95boxObjects2= [];
gdjs._24320_22987_22330_26223Code.GDLawn_95boxObjects3= [];
gdjs._24320_22987_22330_26223Code.GDLawn_95boxObjects4= [];
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects1= [];
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects2= [];
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects3= [];
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects4= [];
gdjs._24320_22987_22330_26223Code.GDFeather_95particleObjects1= [];
gdjs._24320_22987_22330_26223Code.GDFeather_95particleObjects2= [];
gdjs._24320_22987_22330_26223Code.GDFeather_95particleObjects3= [];
gdjs._24320_22987_22330_26223Code.GDFeather_95particleObjects4= [];
gdjs._24320_22987_22330_26223Code.GDDestructible_95walls_95FractureObjects1= [];
gdjs._24320_22987_22330_26223Code.GDDestructible_95walls_95FractureObjects2= [];
gdjs._24320_22987_22330_26223Code.GDDestructible_95walls_95FractureObjects3= [];
gdjs._24320_22987_22330_26223Code.GDDestructible_95walls_95FractureObjects4= [];
gdjs._24320_22987_22330_26223Code.GDDestructible_95wallsObjects1= [];
gdjs._24320_22987_22330_26223Code.GDDestructible_95wallsObjects2= [];
gdjs._24320_22987_22330_26223Code.GDDestructible_95wallsObjects3= [];
gdjs._24320_22987_22330_26223Code.GDDestructible_95wallsObjects4= [];
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects1= [];
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects2= [];
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects3= [];
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects4= [];
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1= [];
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects2= [];
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects3= [];
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects4= [];
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDCactus_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDCactus_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDCactus_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDCactus_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDCactus_9502Objects1= [];
gdjs._24320_22987_22330_26223Code.GDCactus_9502Objects2= [];
gdjs._24320_22987_22330_26223Code.GDCactus_9502Objects3= [];
gdjs._24320_22987_22330_26223Code.GDCactus_9502Objects4= [];
gdjs._24320_22987_22330_26223Code.GDFLOWERObjects1= [];
gdjs._24320_22987_22330_26223Code.GDFLOWERObjects2= [];
gdjs._24320_22987_22330_26223Code.GDFLOWERObjects3= [];
gdjs._24320_22987_22330_26223Code.GDFLOWERObjects4= [];
gdjs._24320_22987_22330_26223Code.GDgrass_951Objects1= [];
gdjs._24320_22987_22330_26223Code.GDgrass_951Objects2= [];
gdjs._24320_22987_22330_26223Code.GDgrass_951Objects3= [];
gdjs._24320_22987_22330_26223Code.GDgrass_951Objects4= [];
gdjs._24320_22987_22330_26223Code.GDgrass_952Objects1= [];
gdjs._24320_22987_22330_26223Code.GDgrass_952Objects2= [];
gdjs._24320_22987_22330_26223Code.GDgrass_952Objects3= [];
gdjs._24320_22987_22330_26223Code.GDgrass_952Objects4= [];
gdjs._24320_22987_22330_26223Code.GDstone_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDstone_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDstone_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDstone_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDstone_9502Objects1= [];
gdjs._24320_22987_22330_26223Code.GDstone_9502Objects2= [];
gdjs._24320_22987_22330_26223Code.GDstone_9502Objects3= [];
gdjs._24320_22987_22330_26223Code.GDstone_9502Objects4= [];
gdjs._24320_22987_22330_26223Code.GDstone_9503Objects1= [];
gdjs._24320_22987_22330_26223Code.GDstone_9503Objects2= [];
gdjs._24320_22987_22330_26223Code.GDstone_9503Objects3= [];
gdjs._24320_22987_22330_26223Code.GDstone_9503Objects4= [];
gdjs._24320_22987_22330_26223Code.GDT_95smoke_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDT_95smoke_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDT_95smoke_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDT_95smoke_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemyObjects1= [];
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemyObjects2= [];
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemyObjects3= [];
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemyObjects4= [];
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemyObjects1= [];
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemyObjects2= [];
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemyObjects3= [];
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemyObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95SiWangObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95SiWangObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95SiWangObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayer_95SiWangObjects4= [];
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemy_95SiWangObjects1= [];
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemy_95SiWangObjects2= [];
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemy_95SiWangObjects3= [];
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemy_95SiWangObjects4= [];
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemy_95SiWangObjects1= [];
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemy_95SiWangObjects2= [];
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemy_95SiWangObjects3= [];
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemy_95SiWangObjects4= [];
gdjs._24320_22987_22330_26223Code.GDUI_95guan_95ka_95zhiObjects1= [];
gdjs._24320_22987_22330_26223Code.GDUI_95guan_95ka_95zhiObjects2= [];
gdjs._24320_22987_22330_26223Code.GDUI_95guan_95ka_95zhiObjects3= [];
gdjs._24320_22987_22330_26223Code.GDUI_95guan_95ka_95zhiObjects4= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9501Objects1= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9501Objects2= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9501Objects3= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9501Objects4= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9502Objects1= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9502Objects2= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9502Objects3= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9502Objects4= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9503Objects1= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9503Objects2= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9503Objects3= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9503Objects4= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9504Objects1= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9504Objects2= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9504Objects3= [];
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9504Objects4= [];
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects1= [];
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2= [];
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects3= [];
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects4= [];
gdjs._24320_22987_22330_26223Code.GDplayObjects1= [];
gdjs._24320_22987_22330_26223Code.GDplayObjects2= [];
gdjs._24320_22987_22330_26223Code.GDplayObjects3= [];
gdjs._24320_22987_22330_26223Code.GDplayObjects4= [];

gdjs._24320_22987_22330_26223Code.conditionTrue_0 = {val:false};
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0 = {val:false};
gdjs._24320_22987_22330_26223Code.condition1IsTrue_0 = {val:false};
gdjs._24320_22987_22330_26223Code.condition2IsTrue_0 = {val:false};
gdjs._24320_22987_22330_26223Code.conditionTrue_1 = {val:false};
gdjs._24320_22987_22330_26223Code.condition0IsTrue_1 = {val:false};
gdjs._24320_22987_22330_26223Code.condition1IsTrue_1 = {val:false};
gdjs._24320_22987_22330_26223Code.condition2IsTrue_1 = {val:false};


gdjs._24320_22987_22330_26223Code.eventsList0xe86a64 = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition0IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12074980);
}
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xe86a64
gdjs._24320_22987_22330_26223Code.eventsList0x13a32dc = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition0IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13360444);
}
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0x13a32dc
gdjs._24320_22987_22330_26223Code.eventsList0xc2d5b4 = function(runtimeScene) {

{

gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.createFrom(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2);


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(1)) >= 180 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[k] = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0xe86a64(runtimeScene);} //End of subevents
}

}


{

gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.createFrom(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2);


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(1)) <= 60 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[k] = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0x13a32dc(runtimeScene);} //End of subevents
}

}


{

gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.createFrom(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2);


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[k] = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3[i].getVariables().getFromIndex(1)).sub(2);
}
}}

}


{

/* Reuse gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2 */

gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[k] = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[i].getVariables().getFromIndex(1)).add(2);
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xc2d5b4
gdjs._24320_22987_22330_26223Code.eventsList0xa4983c = function(runtimeScene) {

{



}


{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2.createFrom(runtimeScene.getObjects("Red_Rune_light"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[i].setOpacity((gdjs.RuntimeObject.getVariableNumber(gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[i].getVariables().getFromIndex(1))));
}
}
{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0xc2d5b4(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xa4983c
gdjs._24320_22987_22330_26223Code.eventsList0xfc93fc = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition0IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(18355772);
}
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(0)).setNumber(0);
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xfc93fc
gdjs._24320_22987_22330_26223Code.eventsList0xf774c4 = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition0IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12304004);
}
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(0)).setNumber(1);
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xf774c4
gdjs._24320_22987_22330_26223Code.eventsList0x115be94 = function(runtimeScene) {

{

gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.createFrom(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1);


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(1)) >= 180 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[k] = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0xfc93fc(runtimeScene);} //End of subevents
}

}


{

gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.createFrom(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1);


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(1)) <= 60 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[k] = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0xf774c4(runtimeScene);} //End of subevents
}

}


{

gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.createFrom(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1);


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(0)) == 0 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[k] = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].getVariables().getFromIndex(1)).sub(2);
}
}}

}


{

/* Reuse gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1 */

gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1[i].getVariables().getFromIndex(0)) == 1 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1[k] = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1[i].getVariables().getFromIndex(1)).add(2);
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0x115be94
gdjs._24320_22987_22330_26223Code.eventsList0xb66ee4 = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.common.logicalNegation(false);
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1.createFrom(runtimeScene.getObjects("Blue_Rune_light"));
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects1.createFrom(runtimeScene.getObjects("Red_Rune_light"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1[i].setOpacity((gdjs.RuntimeObject.getVariableNumber(((gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects1.length === 0 ) ? gdjs.VariablesContainer.badVariablesContainer : gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects1[0].getVariables()).getFromIndex(1))));
}
}
{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0x115be94(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xb66ee4
gdjs._24320_22987_22330_26223Code.eventsList0x103bdb4 = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.createFrom(runtimeScene.getObjects("Blue_Rune_light"));
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2.createFrom(runtimeScene.getObjects("Red_Rune_light"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2[i].setBlendMode(1);
}
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("红色符文石的背后光亮"); }gdjs._24320_22987_22330_26223Code.eventsList0xa4983c(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("红色符文石的背后光亮"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("蓝色符文石的背后光亮"); }gdjs._24320_22987_22330_26223Code.eventsList0xb66ee4(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("蓝色符文石的背后光亮"); }
}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0x103bdb4
gdjs._24320_22987_22330_26223Code.eventsList0xd31f84 = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition0IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(10823548);
}
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.random(6));
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomFloatInRange(1.5, 2));
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xd31f84
gdjs._24320_22987_22330_26223Code.eventsList0xbbcf9c = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition0IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(13421028);
}
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.random(6));
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomFloatInRange(1.5, 2));
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xbbcf9c
gdjs._24320_22987_22330_26223Code.eventsList0x11de9a4 = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition0IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(19933132);
}
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].clearForces();
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0x11de9a4
gdjs._24320_22987_22330_26223Code.eventsList0xb178e4 = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition0IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(12349908);
}
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1[i].clearForces();
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xb178e4
gdjs._24320_22987_22330_26223Code.eventsList0xfd5d2c = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].setBlendMode(2);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(0)).setNumber(gdjs.random(6));
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(2)).setNumber(gdjs.randomFloatInRange(1.5, 2));
}
}}

}


{


{
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].setAnimation((gdjs.RuntimeObject.getVariableNumber(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(0))));
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].setScale((gdjs.RuntimeObject.getVariableNumber(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(2))));
}
}}

}


{

gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));

gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getX() <= -(500) ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[k] = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(1)).setNumber(0);
}
}
{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0xd31f84(runtimeScene);} //End of subevents
}

}


{

gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));

gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getX() >= 1800 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[k] = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].returnVariable(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(1)).setNumber(1);
}
}
{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0xbbcf9c(runtimeScene);} //End of subevents
}

}


{

gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.createFrom(runtimeScene.getObjects("smoke_01"));

gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].getVariables().getFromIndex(1)) == 1 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[k] = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2[i].addForce(gdjs.randomInRange(-(30), -(60)), 0, 0);
}
}
{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0x11de9a4(runtimeScene);} //End of subevents
}

}


{

gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1.createFrom(runtimeScene.getObjects("smoke_01"));

gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
for(var i = 0, k = 0, l = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1.length;i<l;++i) {
    if ( gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1[i].getVariableNumber(gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1[i].getVariables().getFromIndex(1)) == 0 ) {
        gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = true;
        gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1[k] = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1[i];
        ++k;
    }
}
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1.length = k;}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
/* Reuse gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1 */
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1[i].addForce(gdjs.randomInRange(30, 60), 0, 0);
}
}
{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0xb178e4(runtimeScene);} //End of subevents
}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xfd5d2c
gdjs._24320_22987_22330_26223Code.eventsList0xeeccc4 = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2.createFrom(runtimeScene.getObjects("Crazy_bounce_ball"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2[i].setOutline("46;1;1", 12);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2[i].setShadow("34;16;16", 8, 20, 40);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2[i].showShadow(true);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2[i].setPadding(50);
}
}}

}


{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
gdjs._24320_22987_22330_26223Code.GDplayObjects2.createFrom(runtimeScene.getObjects("play"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDplayObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDplayObjects2[i].setOutline("46;1;1", 12);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDplayObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDplayObjects2[i].setShadow("34;16;16", 8, 20, 40);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDplayObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDplayObjects2[i].showShadow(true);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDplayObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDplayObjects2[i].setTextAlignment("center");
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDplayObjects2.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDplayObjects2[i].setPadding(50);
}
}}

}


{


{
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects1.createFrom(runtimeScene.getObjects("Crazy_bounce_ball"));
gdjs._24320_22987_22330_26223Code.GDplayObjects1.createFrom(runtimeScene.getObjects("play"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects1[i].getBehavior("Tween").addObjectPositionYTween("move", 128, "linear", 300, false);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDplayObjects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDplayObjects1[i].getBehavior("Tween").addObjectPositionYTween("move_play", 386, "linear", 300, false);
}
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xeeccc4
gdjs._24320_22987_22330_26223Code.eventsList0x1058dfc = function(runtimeScene) {

{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.input.isMouseButtonReleased(runtimeScene, "Left");
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "场景_G1_01", false);
}}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0x1058dfc
gdjs._24320_22987_22330_26223Code.eventsList0xb5aa0 = function(runtimeScene) {

{



}


{



}


{



}


{



}


{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1.createFrom(runtimeScene.getObjects("B_Red_Warning_Mask_01"));
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects1.createFrom(runtimeScene.getObjects("Border_collision"));
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects1.createFrom(runtimeScene.getObjects("Forest_Tile"));
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1.createFrom(runtimeScene.getObjects("Stone_Frame_Collision_shadow_1"));
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects1.createFrom(runtimeScene.getObjects("Stone_Frame_Collision_shadow_2"));
{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects1[i].hide();
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects1[i].setColor("136;136;136");
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1[i].setBlendMode(2);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1[i].setColor("41;144;255");
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects1[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects1[i].setBlendMode(1);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1[i].setOpacity(180);
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1[i].setColor("13;50;167");
}
}{for(var i = 0, len = gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1.length ;i < len;++i) {
    gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1[i].setBlendMode(2);
}
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("蓝色和红色符文石的背后光亮"); }gdjs._24320_22987_22330_26223Code.eventsList0x103bdb4(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("蓝色和红色符文石的背后光亮"); }
}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("背景烟雾"); }gdjs._24320_22987_22330_26223Code.eventsList0xfd5d2c(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("背景烟雾"); }
}


{



}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{



}


{



}


{



}


{



}


{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
gdjs._24320_22987_22330_26223Code.condition1IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.input.isKeyPressed(runtimeScene, "r");
}if ( gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val ) {
{
{gdjs._24320_22987_22330_26223Code.conditionTrue_1 = gdjs._24320_22987_22330_26223Code.condition1IsTrue_0;
gdjs._24320_22987_22330_26223Code.conditionTrue_1.val = runtimeScene.getOnceTriggers().triggerOnce(20258868);
}
}}
if (gdjs._24320_22987_22330_26223Code.condition1IsTrue_0.val) {
{gdjs.evtTools.runtimeScene.replaceScene(runtimeScene, "场景_G1_01", false);
}}

}


{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.runtimeScene.sceneJustBegins(runtimeScene);
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
{gdjs.evtTools.sound.playSound(runtimeScene, "map\\sound\\Chang_Jing_sound.ogg", true, 40, 1);
}}

}


{


if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().begin("字体设定"); }gdjs._24320_22987_22330_26223Code.eventsList0xeeccc4(runtimeScene);if (runtimeScene.getProfiler()) { runtimeScene.getProfiler().end("字体设定"); }
}


{



}


{



}


{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)) < 300;
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {
{runtimeScene.getVariables().getFromIndex(8).add(1);
}}

}


{


gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = false;
{
gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val = gdjs.evtTools.common.getVariableNumber(runtimeScene.getVariables().getFromIndex(8)) > 100;
}if (gdjs._24320_22987_22330_26223Code.condition0IsTrue_0.val) {

{ //Subevents
gdjs._24320_22987_22330_26223Code.eventsList0x1058dfc(runtimeScene);} //End of subevents
}

}


{


{
}

}


{


{
}

}


{


{
}

}


{


{
}

}


}; //End of gdjs._24320_22987_22330_26223Code.eventsList0xb5aa0


gdjs._24320_22987_22330_26223Code.func = function(runtimeScene) {
runtimeScene.getOnceTriggers().startNewFrame();

gdjs._24320_22987_22330_26223Code.GDplayerObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayerObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayerObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayerObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95yuanObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95yuanObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95yuanObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95yuanObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95shadowObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95shadowObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95shadowObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95shadowObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95moveObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95moveObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95moveObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95moveObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95mouse_95positionObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95mouse_95positionObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95mouse_95positionObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95mouse_95positionObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95followObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95followObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95followObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95followObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDBorder_95collisionObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95circular_95001Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95circular_95001Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95circular_95001Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95circular_95001Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95enemy_95001Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95enemy_95001Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95enemy_95001Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95enemy_95001Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95yellowObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95yellowObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95yellowObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95yellowObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95siwang_95001Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95siwang_95001Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95siwang_95001Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95effects_95siwang_95001Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95RedObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95RedObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95RedObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95RedObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95blueObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95blueObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95blueObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95starlight_95blueObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9502Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9502Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9502Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Red_95Warning_95Mask_9502Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95lightObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95Lizi_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95Lizi_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95Lizi_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDRed_95Rune_95Lizi_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95lightObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95Lizi_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95Lizi_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95Lizi_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDBlue_95Rune_95Lizi_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95playerObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95playerObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95playerObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95playerObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9504_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9503Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9503Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9503Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9503Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9502Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9502Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9502Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9502Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9505Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9505Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9505Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Violet_9505Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95enemy_95UIObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95enemy_95UIObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95enemy_95UIObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95enemy_95UIObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95enemy_95UIObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95enemy_95UIObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95enemy_95UIObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95enemy_95UIObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95kaishi_95timeObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95kaishi_95timeObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95kaishi_95timeObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95kaishi_95timeObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Game_95overObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Game_95overObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Game_95overObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Game_95overObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95geshuObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95geshuObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95geshuObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Blue_95geshuObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95geshuObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95geshuObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95geshuObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95Red_95geshuObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Scene_95crossingObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Scene_95crossingObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Scene_95crossingObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95Scene_95crossingObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95ChuanSongMen_95001Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95ChuanSongMen_95001Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95ChuanSongMen_95001Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDB_95ChuanSongMen_95001Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDGrassland_95TileObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDGrassland_95TileObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDGrassland_95TileObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDGrassland_95TileObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDLawn_95boxObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDLawn_95boxObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDLawn_95boxObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDLawn_95boxObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDForest_95TileObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDFeather_95particleObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDFeather_95particleObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDFeather_95particleObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDFeather_95particleObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDDestructible_95walls_95FractureObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDDestructible_95walls_95FractureObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDDestructible_95walls_95FractureObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDDestructible_95walls_95FractureObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDDestructible_95wallsObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDDestructible_95wallsObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDDestructible_95wallsObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDDestructible_95wallsObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_952Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDStone_95Frame_95Collision_95shadow_951Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDsmoke_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDCactus_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDCactus_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDCactus_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDCactus_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDCactus_9502Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDCactus_9502Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDCactus_9502Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDCactus_9502Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDFLOWERObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDFLOWERObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDFLOWERObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDFLOWERObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDgrass_951Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDgrass_951Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDgrass_951Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDgrass_951Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDgrass_952Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDgrass_952Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDgrass_952Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDgrass_952Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9502Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9502Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9502Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9502Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9503Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9503Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9503Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDstone_9503Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95smoke_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95smoke_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95smoke_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95smoke_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemyObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemyObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemyObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemyObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemyObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemyObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemyObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemyObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95SiWangObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95SiWangObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95SiWangObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayer_95SiWangObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemy_95SiWangObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemy_95SiWangObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemy_95SiWangObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Blue_95enemy_95SiWangObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemy_95SiWangObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemy_95SiWangObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemy_95SiWangObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDE_95Red_95enemy_95SiWangObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95guan_95ka_95zhiObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95guan_95ka_95zhiObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95guan_95ka_95zhiObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDUI_95guan_95ka_95zhiObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9501Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9501Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9501Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9501Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9502Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9502Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9502Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9502Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9503Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9503Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9503Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9503Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9504Objects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9504Objects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9504Objects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDT_95caidi_95bian_9504Objects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDCrazy_95bounce_95ballObjects4.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayObjects1.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayObjects2.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayObjects3.length = 0;
gdjs._24320_22987_22330_26223Code.GDplayObjects4.length = 0;

gdjs._24320_22987_22330_26223Code.eventsList0xb5aa0(runtimeScene);
return;

}
gdjs['_24320_22987_22330_26223Code'] = gdjs._24320_22987_22330_26223Code;
